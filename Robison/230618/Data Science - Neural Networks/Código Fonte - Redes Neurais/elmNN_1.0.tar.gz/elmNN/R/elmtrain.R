elmtrain <-
function(x, ...) UseMethod("elmtrain")
